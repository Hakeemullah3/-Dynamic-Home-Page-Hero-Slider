const slides = document.querySelectorAll(".slide");
const prev = document.querySelector(".prev");
const next = document.querySelector(".next");
const dotsContainer = document.querySelector(".dots");

let index = 0;

// Create dots dynamically
slides.forEach((_, i) => {
    let dot = document.createElement("span");
    dot.classList.add("dot");
    if (i === 0) dot.classList.add("active");
    dot.addEventListener("click", () => showSlide(i));
    dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll(".dot");

function showSlide(i) {
    slides[index].classList.remove("active");
    dots[index].classList.remove("active");

    index = i;

    slides[index].classList.add("active");
    dots[index].classList.add("active");
}

function nextSlide() {
    let newIndex = (index + 1) % slides.length;
    showSlide(newIndex);
}

function prevSlide() {
    let newIndex = (index - 1 + slides.length) % slides.length;
    showSlide(newIndex);
}

next.addEventListener("click", nextSlide);
prev.addEventListener("click", prevSlide);

// Auto Slide (every 4 seconds)
setInterval(nextSlide, 4000);